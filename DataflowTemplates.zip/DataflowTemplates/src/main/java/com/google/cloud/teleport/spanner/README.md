This directory contains sources for Beam pipelines related to Cloud Spanner.

*   Export from Spanner to Avro files in GCS (`ExportPipeline.java`).
*   Import from Avro files to Spanner (`ImportPipeline.java`).
*   Import from CSV files to Spanner (`TextImportPipeline.java`).
